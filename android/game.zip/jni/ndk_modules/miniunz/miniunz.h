#ifndef _miniunz_H
#define _miniunz_H

#ifdef __cplusplus
extern "C" {
#endif

int unzip(const char *zipfilename, const char *dirname);

#ifdef __cplusplus
}
#endif

#endif
