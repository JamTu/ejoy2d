return {
	{
		component = 	{
			{id = 3},
			{name = "fire"},
			{name = "ice"}
		},
		export = "fire",
		type = "animation",
		id = 0,
		{
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,2208,80}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,2152,78}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,2097,76}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,2042,74}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1986,72}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1931,70}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1876,69}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1820,67}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1765,65}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1710,63}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1654,61}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {1024,0,0,1024,-672,688}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1599,59}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {955,0,0,1024,-661,852}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1544,58}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {887,0,0,1024,-650,1016}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1488,56}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {819,0,0,1024,-640,1180}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1433,54}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {750,0,0,1024,-629,1344}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1378,52}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {682,0,0,1024,-618,1508}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1322,50}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {614,0,0,1024,-608,1672}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1267,48}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {546,0,0,1024,-597,1836}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1212,47}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {477,0,0,1024,-586,2000}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1157,45}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {409,0,0,1024,-576,2164}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1101,43}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {341,0,0,1024,-565,2328}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,1046,41}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {273,0,0,1024,-554,2492}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,991,39}
				},			{
					color = 0xffffffff,
					index = 2,
					add = 0x00,
					mat = {204,0,0,1024,-544,2656}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,935,37}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,880,36}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,825,34}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,769,32}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,714,30}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,659,28}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,603,26}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,548,25}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,493,23}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,437,21}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,382,19}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,327,17}
				}},
			{			{
					index = 0
				},			{
					color = 0xffffffff,
					index = 1,
					add = 0x00,
					mat = {1024,0,0,2048,272,16}
				}}
		}
	},
	{
		{
			tex = 1,
			src = {3,3,3,107,239,107,239,3},
			screen = {-1968,-3199.99,-1968,-1535.99,1808,-1535.99,1808,-3199.99}
		},
		type = "picture",
		id = 3
	},
	{
		{
			tex = 1,
			src = {3,111,3,175,67,175,67,111},
			screen = {-512,-512,-512,512,512,512,512,-512}
		},
		type = "picture",
		id = 4
	},
	{
		{
			tex = 1,
			src = {3,179,3,243,66,243,66,179},
			screen = {-504,-512,-504,512,504,512,504,-512}
		},
		type = "picture",
		id = 5
	}
}